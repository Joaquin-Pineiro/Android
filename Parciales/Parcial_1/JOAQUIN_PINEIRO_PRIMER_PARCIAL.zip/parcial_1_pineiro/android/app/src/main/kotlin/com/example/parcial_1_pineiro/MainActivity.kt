package com.example.parcial_1_pineiro

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
